from flask import Flask, request, redirect, render_template, session, flash
app = Flask(__name__)
app.secret_key = "123lol"

class Gold(object):
	def __init__(self):
		self.count = 0

gold = Gold()

@app.route('/')
def index():
	session['gold_count'] = gold.count
	return render_template('index.html')

@app.route('/process_money', methods=['POST'])
def process_money():
	name = request.form['action']
	if(name == 'hidden_farm'):
		gold.count += 10
		flash("Farming earned 15 gold.", 'gold')
	elif name == "hidden_cave":
		gold.count += 5
		flash('Looked in cave, got 7 gold', 'gold')
	elif name == "hidden_house":
		gold.count += 2
		flash('House earned 2 gold','gold')
	elif name == "hidden_casino":
		gold.count += 50
		flash("Have to spend money to make money..", "gold")
	return redirect('/')

@app.route('/reset')
def reset():
	print "You lost all of your gold!"
	session.pop('gold_count')
	gold.count = 0
	return redirect('/')
app.run(debug=True)
